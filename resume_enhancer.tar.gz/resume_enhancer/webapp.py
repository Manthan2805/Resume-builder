import streamlit as st
import pdfplumber
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import re

st.title("Candidate Selection Tool")

st.subheader("NLP Based Resume Screening")

st.caption("Aim of this project is to check whether a candidate is qualified for a role based on the skills mentioned in the job description and those present in their resume.")

uploadedJDs = st.file_uploader("Upload Job Descriptions (Multiple PDFs)", type="pdf", accept_multiple_files=True)

uploadedResume = st.file_uploader("Upload resume", type="pdf")

click = st.button("Process")

# Initialize job_description and resume to empty strings
job_descriptions = []
resume = ""

# ... (your existing code for file uploading and PDF extraction) ...

# Extract skills from a job description
def extract_skills(job_description_text):
    # Define a list of skills to look for in the job description
    skills_to_match = ["Python", "Machine Learning", "Data Analysis", "Data Science", "SQL", "Communication", "Problem Solving"]

    # Initialize a list to store matching skills
    matching_skills = []

    for skill in skills_to_match:
        if re.search(r'\b' + skill + r'\b', job_description_text, re.IGNORECASE):
            matching_skills.append(skill)

    return matching_skills

# Logic to find key points from skills section
def getMatchingKeyPoints(JD_txt, resume_txt, num_points=None):
    # Extract skills from job description and resume
    job_description_skills = extract_skills(JD_txt)
    resume_skills = extract_skills(resume_txt)

    # Find common skills between job description and resume
    common_skills = list(set(job_description_skills) & set(resume_skills))

    return common_skills

# Button to process and find key points
if click:
    if uploadedJDs and uploadedResume:
        for uploadedJD in uploadedJDs:
            with pdfplumber.open(uploadedJD) as pdf:
                pages = pdf.pages[0]
                job_description = pages.extract_text()
                job_descriptions.append(job_description)

        with pdfplumber.open(uploadedResume) as pdf:
            pages = pdf.pages[0]
            resume = pages.extract_text()

    if job_descriptions and resume:  # Check if both job_descriptions and resume are defined
        for idx, job_description in enumerate(job_descriptions):
            st.write(f"Job Description {idx + 1}:")
            st.write(job_description)
            st.write("Skills Matching the Job Description:")
            matching_skills = getMatchingKeyPoints(job_description, resume)
            if matching_skills:
                for i, skill in enumerate(matching_skills):
                    st.write(f"{i + 1}. {skill}")
            else:
                st.write("No matching skills found between the job description and the resume.")

    else:
        st.write("Error: Please upload both job descriptions and a resume.")

st.caption(" ~ made by PMMJ")
