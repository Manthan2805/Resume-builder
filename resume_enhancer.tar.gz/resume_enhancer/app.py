import os
import PyPDF2
import spacy
from flask import Flask, render_template, request, redirect, url_for, send_file
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.lib.styles import getSampleStyleSheet
from io import BytesIO
from weasyprint import HTML

# Load the spaCy English language model
nlp = spacy.load("en_core_web_sm")

app = Flask(__name__, template_folder='/path/to/templates')

app.config['UPLOAD_FOLDER'] = 'uploads'

# Define the path to the HTML template
template_path = 'resume_template.html'


def read_pdf(file_path):
    text = ""
    # Open the PDF file and extract text
    with open(file_path, 'rb') as pdf_file:
        pdf_reader = PyPDF2.PdfReader(pdf_file)
        for page in pdf_reader.pages:
            text += page.extract_text()
    return text

def enhance_resume(resume_text):
    # Parse the resume text using spaCy
    doc = nlp(resume_text)
    
    # Initialize an enhanced resume
    enhanced_resume = []

    for token in doc:
        # Check if the token is a named entity (e.g., a person's name, organization)
        if token.ent_type_:
            # Enhance named entities (e.g., capitalize names)
            enhanced_resume.append(token.text.capitalize())
        else:
            # Keep other tokens as they are
            enhanced_resume.append(token.text)

    # Join the enhanced tokens to create an enhanced resume text
    enhanced_resume_text = " ".join(enhanced_resume)

    return enhanced_resume_text

@app.route('/', methods=['GET', 'POST'])
def upload_resume():
    if request.method == 'POST':
        if 'file' not in request.files:
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            return redirect(request.url)
        if file:
            filename = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(filename)
            enhanced_resume = enhance_resume(read_pdf(filename))
            generate_pdf_with_template(enhanced_resume)
            return send_file('enhanced_resume.pdf', as_attachment=True, download_name="enhanced_resume.pdf")

    return render_template('upload.html')

def generate_pdf_with_template(enhanced_resume):
    # Load the HTML template
    html_template = render_template(template_path)
    
    # Convert the HTML template into a PDF
    pdf_io = BytesIO()
    HTML(string=html_template).write_pdf(pdf_io)
    
    # Create a PDF document with the enhanced resume text
    doc = SimpleDocTemplate(pdf_io, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []
    elements.append(Paragraph(enhanced_resume, styles["Normal"]))
    doc.build(elements)
    
    # Save the PDF
    pdf_io.seek(0)
    with open('enhanced_resume.pdf', 'wb') as pdf_file:
        pdf_file.write(pdf_io.read())

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    app.run(debug=True)

