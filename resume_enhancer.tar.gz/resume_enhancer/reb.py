import os
import pdfkit
from flask import Flask, render_template, request, Response

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate_resume():
    data = {
        'name': request.form.get('name'),
        'email': request.form.get('email'),
        'phone': request.form.get('phone'),
        'objective': request.form.get('objective'),
        'skills': request.form.get('skills'),
        'education': request.form.get('education'),
        'internship': request.form.get('internship'),
        'linkedin': request.form.get('linkedin'),
        'address': request.form.get('address'),
        'certification': request.form.get('certification'),
        'projects': request.form.get('projects'),
    }
    
    # Generate the resume HTML from the template
    resume_html = render_template('resume.html', data=data)
    
    # Generate PDF using pdfkit
    pdfkit.from_string(resume_html, 'resume.pdf', options={'page-size': 'A4'})
    
    # Provide the PDF as a downloadable file
    with open('resume.pdf', 'rb') as pdf_file:
        response = Response(pdf_file.read())
        response.headers['Content-Type'] = 'application/pdf'
        response.headers['Content-Disposition'] = 'inline; filename=resume.pdf'
    return response

if __name__ == '__main__':
    app.run(debug=True)
